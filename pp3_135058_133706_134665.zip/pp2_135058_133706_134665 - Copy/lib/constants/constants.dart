import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryColor = Color(0xFF489088);
  static const Color secondaryColor = Color(0x66A79B84);
  static const Color backgroundColor = Color(0xFFF3EEDF);
}

class AppTextStyles {
  // Original styles
  static const TextStyle headerStyle = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold,
    fontFamily: 'Calibri',
  );

  static const TextStyle subHeaderStyle = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
  );

  static const TextStyle normalTextStyle = TextStyle(fontSize: 16);

  // Material-compatible aliases
  static const TextStyle displayLarge = headerStyle;
  static const TextStyle titleMedium = subHeaderStyle;
  static const TextStyle bodyLarge = normalTextStyle;
}