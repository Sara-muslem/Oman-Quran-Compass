import 'School.dart';
import 'Course.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

List registeredSchools = [];
List _courses = []; // Private field
List get courses => _courses; // Getter method

// Add course to Firestore AND local list
void addCourse(Course course) async {
  try {
    // Add to Firestore
    await FirebaseFirestore.instance.collection('courses').add({
      'name': course.name,
      'instructor': course.instructor,
      'type': course.type,
      'mode': course.mode,
      'startDate': course.startDate,
      'endDate': course.endDate,
      'description': course.description,
      'age': course.age, // Fixed missing field
      'gender': course.gender,
      'prerequisites': course.prerequisites,
      'contact': course.contact, // Fixed missing field
      'schoolId': course.schoolId,
      'createdAt': FieldValue.serverTimestamp(),
    });

    // Also add to local list for immediate display
    _courses.add(course);

    print('Course added to Firestore and local list!');
  } catch (e) {
    print('Error adding course: $e');
  }
}

Future fetchCourses() async {
  try {
    final snapshot = await FirebaseFirestore.instance.collection('courses').orderBy('createdAt', descending: true).get();
    _courses = snapshot.docs.map((doc) {
      final data = doc.data();
      return Course(
        data['name'] ?? '',
        data['instructor'] ?? '',
        data['type'] ?? '',
        data['mode'] ?? '',
        data['startDate'] ?? '',
        data['endDate'] ?? '',
        data['description'] ?? '',
        data['age'] ?? '',
        data['gender'] ?? '',
        data['prerequisites'] ?? '',
        data['contact'] ?? '',
        data['schoolId'] ?? '',
      );
    }).toList();
    print('Courses fetched: ${_courses.length}');
  } catch (e) {
    print('Error fetching courses: $e');
  }
}
