import 'package:flutter/material.dart';
import 'loginPage.dart'; // Import the Login Page
import '../constants/constants.dart'; // Assuming you have constants for colors and text styles
import '../widgets/studentBottomNavigationBar.dart';

class DashboardPage extends StatefulWidget {
  // A static list of users (to be filled dynamically via SignUpPage)
  static List<Map<String, String>> users = [];

  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  String _userEmail = '';
  Map<String, String>? currentUser;

  @override
  void initState() {
    super.initState();
    // Assuming the email is passed directly to DashboardPage.
    _loadCurrentUser();
  }

  // Load current user from dynamic list based on email
  _loadCurrentUser() {
    currentUser = DashboardPage.users.firstWhere(
          (user) => user['email'] == _userEmail,
      orElse: () => {},
    );
  }

  // Handle logout action
  _logout() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const LoginPage()),
    );
  }

  // Dummy data for learning progress
  double tahfeedhProgress = 0.75;
  double tajweedProgress = 0.50;
  double tadaburProgress = 0.80;
  double tafseerProgress = 0.60;

  // Dummy data for badges
  List<String> badges = ['Completed Juz 1', 'Perfected Tajweed Rule'];

  // Dummy performance data
  double testScore = 85.0;
  String instructorFeedback = 'Excellent progress in memorization and recitation!';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primaryColor,
        title: Text(
          'Student Dashboard',
          style: AppTextStyles.displayLarge.copyWith(color: Colors.white),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: _logout,
            color: Colors.white,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 40),
            const SizedBox(height: 24),
            Text(
              'Welcome to your dashboard!',
              style: AppTextStyles.displayLarge.copyWith(
                color: AppColors.primaryColor,
              ),
            ),
            const SizedBox(height: 20),
            // Learning Progress Bar Section
            Text(
              'Learning Progress:',
              style: AppTextStyles.bodyLarge,
            ),
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: tahfeedhProgress,
              backgroundColor: Colors.grey[300],
              color: Colors.green,
            ),
            Text('Tahfeedh: ${(tahfeedhProgress * 100).toStringAsFixed(0)}%'),
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: tajweedProgress,
              backgroundColor: Colors.grey[300],
              color: Colors.blue,
            ),
            Text('Tajweed: ${(tajweedProgress * 100).toStringAsFixed(0)}%'),
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: tadaburProgress,
              backgroundColor: Colors.grey[300],
              color: Colors.orange,
            ),
            Text('Tadabur: ${(tadaburProgress * 100).toStringAsFixed(0)}%'),
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: tafseerProgress,
              backgroundColor: Colors.grey[300],
              color: Colors.purple,
            ),
            Text('Tafseer: ${(tafseerProgress * 100).toStringAsFixed(0)}%'),
            const SizedBox(height: 40),
            // Achievement Badges
            Text(
              'Achievements:',
              style: AppTextStyles.bodyLarge,
            ),
            const SizedBox(height: 10),
            ...badges.map((badge) => Row(
              children: [
                Icon(Icons.star, color: Colors.yellow),
                const SizedBox(width: 10),
                Text(badge),
              ],
            )),
            const SizedBox(height: 40),
            // Performance Analytics
            Text(
              'Performance Analytics:',
              style: AppTextStyles.bodyLarge,
            ),
            const SizedBox(height: 10),
            Text('Recent Test Score: ${testScore.toStringAsFixed(0)}%'),
            Text('Instructor Feedback: $instructorFeedback'),
            const SizedBox(height: 40),
            // Set Study Goals Section
            Text(
              'Set Your Study Goals:',
              style: AppTextStyles.bodyLarge,
            ),
            const SizedBox(height: 10),
            TextField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Goal Name',
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                // Handle goal setting logic
              },
              child: const Text('Set Goal'),
            ),
          ],
        ),
      ),
      bottomNavigationBar: CustomBottomNav(currentIndex: 0), // Or 1, 2, 3 depending on the page
    );
  }
}
