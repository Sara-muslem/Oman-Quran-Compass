import 'dart:math';

class School {
  late final String _id;
  String _name;
  double _latitude;
  double _longitude;
  String _logo;
  String _description;
  String _vision;

  /// Constructor for [School].
  School({
    required String name,
    required double latitude,
    required double longitude,
    required String logo,
    required String description,
    required String vision,
  })  : _name = name,
        _latitude = latitude,
        _longitude = longitude,
        _logo = logo,
        _description = description,
        _vision = vision {
    _id = _generateId();
  }

  /// Generates a random unique ID in the format 'ABC123'.
  static String _generateId() {
    final random = Random();
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    String randomLetters =
    List.generate(3, (_) => letters[random.nextInt(letters.length)]).join();
    String randomDigits = (random.nextInt(900) + 100).toString(); // Ensures 3 digits
    return randomLetters + randomDigits;
  }

  // Getters
  String get id => _id;
  String get name => _name;
  double get latitude => _latitude;
  double get longitude => _longitude;
  String get logo => _logo;
  String get description => _description;
  String get vision => _vision;

  /// Returns the Google Maps URL for the school's location.
  String get locationUrl =>
      "https://www.google.com/maps/search/?api=1&query=$_latitude,$_longitude";

  // Setters
  set name(String value) => _name = value;
  set logo(String value) => _logo = value;
  set description(String value) => _description = value;
  set vision(String value) => _vision = value;
}
