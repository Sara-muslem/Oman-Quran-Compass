import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class SchoolLocationMapPage extends StatelessWidget {
  final double latitude;
  final double longitude;

  const SchoolLocationMapPage({
    Key? key,
    required this.latitude,
    required this.longitude,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final LatLng schoolLatLng = LatLng(latitude, longitude);

    return Scaffold(
      appBar: AppBar(
        title: Text('School Location'),
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: schoolLatLng,
          zoom: 15,
        ),
        markers: {
          Marker(
            markerId: MarkerId('school-location'),
            position: schoolLatLng,
            infoWindow: InfoWindow(title: 'School Location'),
          ),
        },
      ),
    );
  }
}
