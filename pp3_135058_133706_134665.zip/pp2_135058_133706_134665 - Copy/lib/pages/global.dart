// global.dart

// A global list to store users (email and password).
List<Map<String, String>> users = [];
// global.dart
String? currentUser; // Define a global variable to store the logged-in user data

