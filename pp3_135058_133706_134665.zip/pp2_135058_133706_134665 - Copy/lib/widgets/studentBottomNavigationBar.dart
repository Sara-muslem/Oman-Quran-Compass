import 'package:flutter/material.dart';
import '../constants/constants.dart';
import '../pages/HomePage.dart';
import '../pages/SearchPage.dart';
import '../pages/studentDashboardPage.dart';
import '../pages/ScoolListPage.dart';

class CustomBottomNav extends StatelessWidget {
  final int currentIndex;

  const CustomBottomNav({
    Key? key,
    required this.currentIndex,
  }) : super(key: key);

  void _onTap(int index, BuildContext context) {
    switch (index) {
      case 0:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomePage()));
        break;
      case 1:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const SearchPage()));
        break;
      case 2:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => DashboardPage()));
        break;
      case 3:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const SchoolListPage(title: "Schools List")));
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      color: AppColors.primaryColor,
      shape: const CircularNotchedRectangle(), // For notch effect if using FAB
      elevation: 8,
      child: SizedBox(
        height: 60,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildNavItem(context, icon: Icons.home, label: 'Home', index: 0),
            _buildNavItem(context, icon: Icons.search, label: 'Search', index: 1),
            _buildNavItem(context, icon: Icons.dashboard, label: 'Dashboard', index: 2),
            _buildNavItem(context, icon: Icons.school, label: 'Schools', index: 3),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(BuildContext context,
      {required IconData icon, required String label, required int index}) {
    final bool isSelected = currentIndex == index;

    return GestureDetector(
      onTap: () => _onTap(index, context),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: isSelected ? AppColors.backgroundColor : Colors.white),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: isSelected ? AppColors.backgroundColor : Colors.white,
              fontSize: 12,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}
