import 'dart:math';

class Course {
  String _courseId;
  String _name;
  String _instructor;
  String _type;
  String _mode;
  String _startDate;
  String _endDate;
  String _description;
  String _age;
  String _gender;
  String _prerequisites;
  String _contact;
  String _schoolId;

  Course(
      this._name,
      this._instructor,
      this._type,
      this._mode,
      this._startDate,
      this._endDate,
      this._description,
      this._age,
      this._gender,
      this._prerequisites,
      this._contact,
      this._schoolId,
      ) : _courseId = _generateCourseId(_type);

  static String _generateCourseId(String type) {
    String prefix;
    switch (type.toLowerCase()) {
      case 'tajweed':
        prefix = 'TAJ';
        break;
      case 'tafseer':
        prefix = 'TAF';
        break;
      case 'tahfeedh':
      case 'memorization':
      case 'hifdh':
        prefix = 'TAH';
        break;
      default:
        prefix = 'GEN';
    }
    final number = Random().nextInt(9000) + 1000;
    return '$prefix$number';
  }

  String get courseId => _courseId;
  String get name => _name;
  String get instructor => _instructor;
  String get type => _type;
  String get mode => _mode;
  String get startDate => _startDate;
  String get endDate => _endDate;
  String get description => _description;
  String get age => _age;
  String get gender => _gender;
  String get prerequisites => _prerequisites;
  String get contact => _contact;
  String get schoolId => _schoolId;

  set name(String value) => _name = value;
  set instructor(String value) => _instructor = value;
  set type(String value) {
    _type = value;
    _courseId = _generateCourseId(_type);
  }
  set mode(String value) => _mode = value;
  set startDate(String value) => _startDate = value;
  set endDate(String value) => _endDate = value;
  set description(String value) => _description = value;
  set age(String value) => _age = value;
  set gender(String value) => _gender = value;
  set prerequisites(String value) => _prerequisites = value;
  set contact(String value) => _contact = value;
  set schoolId(String value) => _schoolId = value;
}

