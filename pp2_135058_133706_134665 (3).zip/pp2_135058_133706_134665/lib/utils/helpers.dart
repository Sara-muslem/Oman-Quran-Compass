import 'package:flutter/material.dart';
import '../constants/constants.dart';

class AppBanner {
  static void showSubmissionBanner(BuildContext context) {
    ScaffoldMessenger.of(context).showMaterialBanner(
      MaterialBanner(
        content: const Text('You have submitted successfully'),
        leading: const Icon(Icons.check_circle, color: Colors.white),
        backgroundColor: AppColors.primaryColor,
        actions: [
          TextButton(
            onPressed: () => _hideBanner(context),
            child: const Text('DISMISS', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    _autoHideBanner(context);
  }

  static void showInfoBanner(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showMaterialBanner(
      MaterialBanner(
        content: Text(message),
        backgroundColor: Colors.teal,
        actions: [
          TextButton(
            onPressed: () => _hideBanner(context),
            child: const Text('CLOSE', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    _autoHideBanner(context);
  }

  static void showSuccess({
    required BuildContext context,
    required String message,
    Duration duration = const Duration(seconds: 3),
  }) {
    final banner = MaterialBanner(
      content: Text(message, style: const TextStyle(color: Colors.white)),
      leading: const Icon(Icons.check_circle, color: Colors.white),
      backgroundColor: AppColors.primaryColor,
      actions: [
        TextButton(
          onPressed: () => _hideBanner(context),
          child: const Text('OK', style: TextStyle(color: Colors.white)),
        ),
      ],
    );
    _showTimedBanner(context, banner, duration);
  }

  static void showError({
    required BuildContext context,
    required String message,
    Duration duration = const Duration(seconds: 4),
  }) {
    final banner = MaterialBanner(
      content: Text(message, style: const TextStyle(color: Colors.white)),
      leading: const Icon(Icons.error, color: Colors.white),
      backgroundColor: Colors.red[700]!,
      actions: [
        TextButton(
          onPressed: () => _hideBanner(context),
          child: const Text('GOT IT', style: TextStyle(color: Colors.white)),
        ),
      ],
    );
    _showTimedBanner(context, banner, duration);
  }

  static void _showTimedBanner(BuildContext context, MaterialBanner banner, [Duration duration = const Duration(seconds: 3)]) {
    ScaffoldMessenger.of(context).showMaterialBanner(banner);
    Future.delayed(duration, () => _hideBanner(context));
  }

  static void _autoHideBanner(BuildContext context, [Duration duration = const Duration(seconds: 3)]) {
    Future.delayed(duration, () => _hideBanner(context));
  }

  static void _hideBanner(BuildContext context) {
    if (ScaffoldMessenger.of(context).mounted) {
      ScaffoldMessenger.of(context).hideCurrentMaterialBanner();
    }
  }
}