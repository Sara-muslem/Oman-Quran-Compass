// global.dart

// A global list to store users (email and password).
List<Map<String, String>> users = [];
