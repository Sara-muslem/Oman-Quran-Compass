import 'package:flutter/material.dart';
import 'loginPage.dart';
import 'global.dart';

class LogoutPage extends StatelessWidget {
  const LogoutPage({Key? key}) : super(key: key);

  void _handleLogout(BuildContext context) {
    // Clear the current user session in memory
    currentUser = null;

    // Navigate to the login page and remove all previous routes
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const LoginPage()),
          (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    // Trigger logout logic after the frame is rendered
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _handleLogout(context);  // Perform logout logic
    });

    // Show a loading indicator while logging out
    return const Scaffold(
      body: Center(child: CircularProgressIndicator()),
    );
  }
}
