// lib/screens/home.dart

import 'package:flutter/material.dart';
import '../constants/constants.dart';
import '../widgets/logo.dart';
import '../widgets/studentBottomNavigationBar.dart'; // Adjust the path as needed


class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String dropdownValue = 'Beginner';
  bool isChecked = false;
  bool isSwitched = false;
  String radioValue = 'Male';
  int _selectedBottomNavIndex = 0;

  // List to store user data


  void _onBottomNavTap(int index) {
    setState(() {
      _selectedBottomNavIndex = index;
    });
  }

  void showInfoBanner(BuildContext context) {
    ScaffoldMessenger.of(context).showMaterialBanner(
      MaterialBanner(
        content: const Text('This mobile app is Oman Quran Compass, where you can find the nearby quran schools'),
        backgroundColor: Colors.teal,
        actions: [
          TextButton(
            onPressed: () {
              ScaffoldMessenger.of(context).hideCurrentMaterialBanner();
            },
            child: const Text(
              'CLOSE',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.primaryColor,
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.info),
            onPressed: () => showInfoBanner(context),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                children: [
                  CustomAvatar(imagePath: 'assets/images/logo.png', radius: 60),
                  SizedBox(height: 12),
                  Text(
                    'Welcome to Quran Compass',
                    style: AppTextStyles.headerStyle.copyWith(
                      color: AppColors.primaryColor, // Applying the primary color here
                    ),
                  )
                ],
              ),
              const SizedBox(height: 20),
              SizedBox(
                height: 180,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    'ad_1.jpg', 'ad_2.jpg', 'ad_3.jpg'
                  ].map((img) => Padding(
                    padding: const EdgeInsets.only(right: 16),
                    child: GestureDetector(
                      onTap: () => debugPrint("Ad clicked!"),
                      child: Image.asset('assets/images/$img', width: 300, fit: BoxFit.cover),
                    ),
                  )).toList(),
                ),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: AppColors.primaryColor),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    //Text('Daily Verse:', style: AppTextStyles.subHeaderStyle),
                    SizedBox(height: 8),
                    Text(
                      'Indeed, this Qur’an guides to that which is most suitable.',
                      style: AppTextStyles.normalTextStyle.copyWith(
                        color: AppColors.primaryColor,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
      bottomNavigationBar: CustomBottomNav(currentIndex: 0), // Or 1, 2, 3 depending on the page
    );
  }
}

void showSubmissionBanner(BuildContext context) {
}