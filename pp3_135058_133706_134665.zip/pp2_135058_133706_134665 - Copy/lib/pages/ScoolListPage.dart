import 'package:flutter/material.dart';
import 'LogoutPage.dart';
import 'SchoolProfilePage.dart';
import '../models/SchoolData.dart';
import 'SchoolDetailsPage.dart';
import '../constants/constants.dart'; // Import the constants
import '../widgets/studentBottomNavigationBar.dart';

class SchoolListPage extends StatefulWidget {
  final String title;
  const SchoolListPage({Key? key, required this.title}) : super(key: key);

  @override
  State<SchoolListPage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<SchoolListPage> {
  void _navigateToRegister() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const SchoolRegistrationPage()),
    );
    setState(() {}); // Triggers rebuild to reflect updated registeredSchools
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        title: Text(widget.title, style: AppTextStyles.headerStyle.copyWith(color: Colors.white)),
        backgroundColor: AppColors.primaryColor,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () {
              // Navigate to the LogoutPage
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const LogoutPage()),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.delete, color: Colors.red),
            onPressed: () {
              setState(() {
                registeredSchools.clear();
              });
            },
          )

        ],
      ),
      body: ListView.builder(
        itemCount: registeredSchools.length,
        itemBuilder: (context, index) {
          final school = registeredSchools[index];
          return Card(
            color: AppColors.backgroundColor,
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: ListTile(
              title: Text(
                school.name,
                style: TextStyle(
                  color: Colors.black87,
                  fontSize: 16,
                ),
              ),
              trailing: const Icon(Icons.arrow_forward, color: Colors.black54),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SchoolProfilePage(school: school),
                  ),
                );
              },
            ),
          );

        },
      ),
      bottomNavigationBar: CustomBottomNav(currentIndex: 3), // Or 1, 2, 3 depending on the page
    );
  }
}
