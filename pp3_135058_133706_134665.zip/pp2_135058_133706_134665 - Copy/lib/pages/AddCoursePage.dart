import 'package:flutter/material.dart';
import '../models/Course.dart';
import '../models/SchoolData.dart';

class AddCoursePage extends StatefulWidget {
  final String schoolId;

  const AddCoursePage({Key? key, required this.schoolId}) : super(key: key);

  @override
  State<AddCoursePage> createState() => _AddCoursePageState();
}

class _AddCoursePageState extends State<AddCoursePage> {
  final _formKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _instructorController = TextEditingController();
  final _typeController = TextEditingController();
  final _modeController = TextEditingController();
  final _startDateController = TextEditingController();
  final _endDateController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _ageController = TextEditingController();
  final _genderController = TextEditingController();
  final _prerequisitesController = TextEditingController();
  final _contactController = TextEditingController();

  void _submitCourse() {
    if (_formKey.currentState!.validate()) {
      final course = Course(
        _nameController.text,
        _instructorController.text,
        _typeController.text,
        _modeController.text,
        _startDateController.text,
        _endDateController.text,
        _descriptionController.text,
        _ageController.text,
        _genderController.text,
        _prerequisitesController.text,
        _contactController.text,
        widget.schoolId,
      );

      addCourse(course);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Course added successfully')),
      );

      Navigator.pop(context, true); // ✅ Indicates success// Go back to the school profile page
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Course')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              _buildTextField(_nameController, 'Course Name'),
              _buildTextField(_instructorController, 'Instructor'),
              _buildTextField(_typeController, 'Course Type (tajweed, tafseer, etc)'),
              _buildTextField(_modeController, 'Mode (online/on-site)'),
              _buildTextField(_startDateController, 'Start Date'),
              _buildTextField(_endDateController, 'End Date'),
              _buildTextField(_descriptionController, 'Description', maxLines: 3),
              _buildTextField(_ageController, 'Age Group'),
              _buildTextField(_genderController, 'Gender'),
              _buildTextField(_prerequisitesController, 'Prerequisites'),
              _buildTextField(_contactController, 'Contact Info'),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submitCourse,
                child: const Text('Add Course'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, {int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextFormField(
        controller: controller,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        validator: (value) => value == null || value.isEmpty ? 'Please enter $label' : null,
      ),
    );
  }
}
