import '../models/School.dart';
import 'package:flutter/material.dart';
import 'schoolProfilePage.dart';

class SchoolEditPage extends StatefulWidget {
  final School school;

  const SchoolEditPage({Key? key, required this.school}) : super(key: key);

  @override
  _SchoolEditPageState createState() => _SchoolEditPageState();
}

class _SchoolEditPageState extends State<SchoolEditPage> {
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _visionController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _nameController.text = widget.school.name;
    _descriptionController.text = widget.school.description;
    _visionController.text = widget.school.vision;
  }

  void _saveChanges() {
    // Create a new updated school object
    final updatedSchool = School(
      name: _nameController.text,
      description: _descriptionController.text,
      vision: _visionController.text,
      logo: widget.school.logo,
      latitude: widget.school.latitude,
      longitude: widget.school.longitude,
    );

    // Return it to the previous page
    Navigator.pop(context, updatedSchool);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit ${widget.school.name}"),

      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'School Name'),
            ),
            TextField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'Description'),
            ),
            TextField(
              controller: _visionController,
              decoration: InputDecoration(labelText: 'Vision'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _saveChanges,
              child: Text('Save Changes'),
            ),
          ],
        ),
      ),
    );
  }
}
