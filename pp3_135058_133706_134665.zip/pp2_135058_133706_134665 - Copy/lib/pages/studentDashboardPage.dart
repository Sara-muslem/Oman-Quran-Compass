import 'package:flutter/material.dart';
import 'LogoutPage.dart';
import 'loginPage.dart'; // Import the Login Page
import '../constants/constants.dart'; // Assuming you have constants for colors and text styles
import '../widgets/studentBottomNavigationBar.dart';

class DashboardPage extends StatefulWidget {
  // A static list of users (to be filled dynamically via SignUpPage)
  static List<Map<String, String>> users = [];

  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  String _userEmail = '';
  Map<String, String>? currentUser;

  @override
  void initState() {
    super.initState();
    // Assuming the email is passed directly to DashboardPage.
    _loadCurrentUser();
  }

  // Load current user from dynamic list based on email
  _loadCurrentUser() {
    currentUser = DashboardPage.users.firstWhere(
          (user) => user['email'] == _userEmail,
      orElse: () => {},
    );
  }

  // Dummy data for learning progress
  double tahfeedhProgress = 0.75;
  double tajweedProgress = 0.50;
  double tadaburProgress = 0.80;
  double tafseerProgress = 0.60;

  // Dummy data for badges
  List<String> badges = ['Completed Juz 1', 'Perfected Tajweed Rule'];

  // Dummy performance data
  double testScore = 85.0;
  String instructorFeedback = 'Excellent progress in memorization and recitation!';

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4, // Define the number of tabs
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: AppColors.primaryColor,
          title: Text(
            'Student Dashboard',
            style: AppTextStyles.displayLarge.copyWith(color: Colors.white),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.logout),
              tooltip: 'Logout',
              onPressed: () {
                // Navigate to the LogoutPage
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => const LogoutPage()),
                );
              },
            ),
          ],
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Progress'),
              Tab(text: 'Achievements'),
              Tab(text: 'Analytics'),
              Tab(text: 'Goals'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            // Progress Tab
            ProgressTab(),

            // Achievements Tab
            AchievementsTab(),

            // Performance Analytics Tab
            AnalyticsTab(),

            // Set Study Goals Tab
            GoalsTab(),
          ],
        ),
        bottomNavigationBar: CustomBottomNav(currentIndex: 2), // Or 1, 2, 3 depending on the page
      ),
    );
  }
}

// Progress Tab
class ProgressTab extends StatelessWidget {
  const ProgressTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Dummy data for learning progress
    double tahfeedhProgress = 0.75;
    double tajweedProgress = 0.50;
    double tadaburProgress = 0.80;
    double tafseerProgress = 0.60;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Learning Progress:',
            style: AppTextStyles.bodyLarge,
          ),
          const SizedBox(height: 10),
          LinearProgressIndicator(
            value: tahfeedhProgress,
            backgroundColor: Colors.grey[300],
            color: Colors.green,
          ),
          Text('Tahfeedh: ${(tahfeedhProgress * 100).toStringAsFixed(0)}%'),
          const SizedBox(height: 10),
          LinearProgressIndicator(
            value: tajweedProgress,
            backgroundColor: Colors.grey[300],
            color: Colors.blue,
          ),
          Text('Tajweed: ${(tajweedProgress * 100).toStringAsFixed(0)}%'),
          const SizedBox(height: 10),
          LinearProgressIndicator(
            value: tadaburProgress,
            backgroundColor: Colors.grey[300],
            color: Colors.orange,
          ),
          Text('Tadabur: ${(tadaburProgress * 100).toStringAsFixed(0)}%'),
          const SizedBox(height: 10),
          LinearProgressIndicator(
            value: tafseerProgress,
            backgroundColor: Colors.grey[300],
            color: Colors.purple,
          ),
          Text('Tafseer: ${(tafseerProgress * 100).toStringAsFixed(0)}%'),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

// Achievements Tab
class AchievementsTab extends StatelessWidget {
  const AchievementsTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Dummy data for badges
    List<String> badges = ['Completed Juz 1', 'Perfected Tajweed Rule'];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Achievements:',
            style: AppTextStyles.bodyLarge,
          ),
          const SizedBox(height: 10),
          ...badges.map((badge) => Row(
            children: [
              Icon(Icons.star, color: Colors.yellow),
              const SizedBox(width: 10),
              Text(badge),
            ],
          )),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

// Performance Analytics Tab
class AnalyticsTab extends StatelessWidget {
  const AnalyticsTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Dummy performance data
    double testScore = 85.0;
    String instructorFeedback = 'Excellent progress in memorization and recitation!';

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Performance Analytics:',
            style: AppTextStyles.bodyLarge,
          ),
          const SizedBox(height: 10),
          Text('Recent Test Score: ${testScore.toStringAsFixed(0)}%'),
          Text('Instructor Feedback: $instructorFeedback'),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

// Set Study Goals Tab
class GoalsTab extends StatelessWidget {
  const GoalsTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Set Your Study Goals:',
            style: AppTextStyles.bodyLarge,
          ),
          const SizedBox(height: 10),
          TextField(
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Goal Name',
            ),
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              // Handle goal setting logic
            },
            child: const Text('Set Goal'),
          ),
        ],
      ),
    );
  }
}
