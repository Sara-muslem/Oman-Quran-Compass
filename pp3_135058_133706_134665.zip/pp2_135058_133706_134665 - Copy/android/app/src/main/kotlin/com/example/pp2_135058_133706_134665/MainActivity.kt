package com.example.pp2_135058_133706_134665

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
