import 'package:flutter/material.dart';
import 'loginPage.dart';
import 'global.dart'; // Import the global.dart file to access the users list
import '../constants/constants.dart'; // Ensure this file contains your color and font constants
import '../widgets/costumSubmitButton.dart'; // Assuming you have a custom button widget
import '../widgets/logo.dart'; // Assuming you have a logo widget
import 'schoolDetailsPage.dart'; // Import the school registration page

class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key}) : super(key: key);

  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;
  String accountType = 'Student'; // Default selection

  void _signUp() {
    if (_formKey.currentState!.validate()) {
      final name = _nameController.text.trim();
      final email = _emailController.text.trim();
      final password = _passwordController.text;

      // Check for existing email
      final isExistingUser = users.any((user) => user['email'] == email);
      if (isExistingUser) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Email already registered')),
        );
        return;
      }

      // Add user
      users.add({
        'name': name,
        'email': email,
        'password': password,
        'accountType': accountType,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('User signed up successfully!')),
      );

      // Navigate based on account type
      if (accountType == 'Student') {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const LoginPage()),
        );
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const SchoolRegistrationPage())
        );}
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 40),
                const Hero(
                  tag: 'app-logo',
                  child: CustomAvatar(imagePath: 'assets/images/logo.png', radius: 60),
                ),
                const SizedBox(height: 24),
                Text(
                  'Oman Quran Compass',
                  style: AppTextStyles.displayLarge.copyWith(
                    color: AppColors.primaryColor,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Create your account',
                  style: AppTextStyles.bodyLarge,
                ),
                const SizedBox(height: 40),

                // Account Type Toggle
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ChoiceChip(
                      label: const Text('Student'),
                      selected: accountType == 'Student',
                      onSelected: (selected) {
                        setState(() => accountType = 'Student');
                      },
                    ),
                    const SizedBox(width: 16),
                    ChoiceChip(
                      label: const Text('School'),
                      selected: accountType == 'School',
                      onSelected: (selected) {
                        setState(() => accountType = 'School');
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // Name
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    labelText: accountType == 'Student' ? 'Student Name' : 'School Name',
                    prefixIcon: const Icon(Icons.person),
                    border: const OutlineInputBorder(),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter your name';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Email
                TextFormField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: accountType == 'Student' ? 'Student Email' : 'School Email',
                    prefixIcon: const Icon(Icons.email),
                    border: const OutlineInputBorder(),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter your email';
                    }
                    if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value.trim())) {
                      return 'Please enter a valid email';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Password
                TextFormField(
                  controller: _passwordController,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    prefixIcon: const Icon(Icons.lock),
                    suffixIcon: IconButton(
                      icon: Icon(_obscurePassword ? Icons.visibility : Icons.visibility_off),
                      onPressed: () {
                        setState(() => _obscurePassword = !_obscurePassword);
                      },
                    ),
                    border: const OutlineInputBorder(),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  obscureText: _obscurePassword,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a password';
                    }
                    if (value.length < 6) {
                      return 'Password must be at least 6 characters';
                    }
                    if (!RegExp(r'^(?=.*[A-Z])').hasMatch(value)) {
                      return 'Password must contain at least one uppercase letter';
                   }
                   if (!RegExp(r'^(?=.*\d)').hasMatch(value)) {
                      return 'Password must contain at least one number';
                  }
                   if (!RegExp(r'^(?=.*[!@#\$%^&*()_+\-=\[\]{};:"\\|,.<>\/?])').hasMatch(value)) {
                     return 'Password must contain at least one special character';
                   }
                   return null;
                  },
                ),
                const SizedBox(height: 24),

                // Submit Button
                CustomSubmitButton(
                  label: 'Sign Up',
                  onPressed: _signUp,
                ),

                const SizedBox(height: 20),
                TextButton(
                  onPressed: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => const LoginPage()),
                    );
                  },
                  child: const Text('Already have an account? Login'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
