import 'School.dart';
import 'Course.dart';

List<School> registeredSchools = [];
List<Course> _courses = [];
List<Course> get courses => _courses;

void addCourse(Course course) {
  _courses.add(course);
}