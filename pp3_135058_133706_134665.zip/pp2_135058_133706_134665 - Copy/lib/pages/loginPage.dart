import 'package:flutter/material.dart';
import 'global.dart';
import 'signupPage.dart';
import '../constants/constants.dart'; // Ensure this file contains your color and font constants
import '../widgets/costumSubmitButton.dart'; // Assuming you have a custom button widget
import '../widgets/logo.dart'; // Assuming you have a logo widget
import '../utils/helpers.dart' as banners;
import 'HomePage.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;
  String loginType = 'Student'; // Default login type is 'Student'

  // User Authentication with Error Handling
  void _login() {
    // Validate the form fields before proceeding
    if (_formKey.currentState!.validate()) {
      final name = _nameController.text;
      final password = _passwordController.text;

      // Access the global list of users and check credentials
      var matchedUser = users.firstWhere(
            (user) => user['name'] == name && user['password'] == password,
        orElse: () => {}, // If no match is found, return an empty map
      );

      // Check if a valid user was found
      if (matchedUser.isNotEmpty) {
        // Store current user in memory (global state)
        currentUser = matchedUser['name'];

        // Show success banner
        banners.AppBanner.showSuccess(
          context: context,
          message: 'Login successful! Redirecting...',
        );

        // Navigate to the respective page based on login type (Student or School)
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => loginType == 'Student' ? HomePage() : SignUpPage(),
          ),
        );
      } else {
        // Show error banner if authentication fails
        banners.AppBanner.showError(
          context: context,
          message: 'Invalid name or password',
        );
      }
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey, // Key for form validation
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 40),
                const Hero(
                  tag: 'app-logo',
                  child: CustomAvatar(imagePath: 'assets/images/logo.png', radius: 60),
                ),
                const SizedBox(height: 24),
                Text(
                  'Oman Quran Compass',
                  style: AppTextStyles.displayLarge.copyWith(
                    color: AppColors.primaryColor,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Continue your Quranic journey',
                  style: AppTextStyles.bodyLarge,
                ),
                const SizedBox(height: 40),

                // Login Type Selection (Student or School)
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ChoiceChip(
                      label: Text('Student'),
                      selected: loginType == 'Student',
                      onSelected: (bool selected) {
                        setState(() {
                          loginType = 'Student';
                        });
                      },
                    ),
                    const SizedBox(width: 16),
                    ChoiceChip(
                      label: Text('School'),
                      selected: loginType == 'School',
                      onSelected: (bool selected) {
                        setState(() {
                          loginType = 'School';
                        });
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 40),

                // Name Field (Email/Name based on login type)
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    labelText: loginType == 'Student' ? 'Student name' : 'School name',
                    prefixIcon: const Icon(Icons.person),
                    border: const OutlineInputBorder(),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  keyboardType: TextInputType.text,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your name';
                    }
                    return null; // No validation errors
                  },
                ),
                const SizedBox(height: 16),

                // Password Field
                TextFormField(
                  controller: _passwordController,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    prefixIcon: const Icon(Icons.lock),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscurePassword
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                      onPressed: () {
                        setState(() => _obscurePassword = !_obscurePassword);
                      },
                    ),
                    border: const OutlineInputBorder(),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  obscureText: _obscurePassword, // Hide the password text
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your password';
                    }
                    if (value.length < 6) {
                      return 'Password must be at least 6 characters';
                    }
                    return null; // No validation errors
                  },
                ),
                const SizedBox(height: 24),

                // Submit Button
                CustomSubmitButton(
                  label: 'Login',
                  onPressed: _login, // Trigger login function
                ),
                const SizedBox(height: 16),

                // Sign Up Text Button
                TextButton(
                  onPressed: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => const SignUpPage()),
                    );
                  },
                  child: const Text('Create an Account'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
