import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import '../models/Course.dart';
import '../models/School.dart';
import '../models/SchoolData.dart';
import 'HomePage.dart';
import 'LogoutPage.dart';
import 'studentDashboardPage.dart';
import '../constants/constants.dart';
import 'signupPage.dart';
import 'schoolDetailsPage.dart';
import '../widgets/studentBottomNavigationBar.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({Key? key}) : super(key: key);

  @override
  State<SearchPage> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchPage> {
  List<Course> filteredCourses = [];
  String searchQuery = '';
  String selectedCategory = 'All';
  String selectedMode = 'All';
  bool showOnlineOnly = false;
  LatLng? userLocation;

  @override
  void initState() {
    super.initState();
    // Make sure courses is explicitly cast as List<Course>
    filteredCourses = List<Course>.from(courses);
    userLocation = const LatLng(23.6100, 58.5400); // Default to Muscat
  }

  void _onBottomNavTap(int index) {
    if (index == 0) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const HomePage()));
    } else if (index == 1) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const SearchPage()));
    } else if (index == 2) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => DashboardPage()));
    }
  }

  void _filterCourses() {
    setState(() {
      filteredCourses = List<Course>.from(courses.where((course) {
        final matchesSearch = course.name.toLowerCase().contains(searchQuery.toLowerCase()) ||
            course.description.toLowerCase().contains(searchQuery.toLowerCase());

        final matchesCategory = selectedCategory == 'All' ||
            course.type.toLowerCase() == selectedCategory.toLowerCase();

        final matchesMode = selectedMode == 'All' ||
            course.mode.toLowerCase() == selectedMode.toLowerCase();

        final matchesOnline = !showOnlineOnly || course.mode.toLowerCase() == 'online';

        return matchesSearch && matchesCategory && matchesMode && matchesOnline;
      }).toList());
    });
  }

  School? _getSchoolForCourse(String schoolId) {
    try {
      return registeredSchools.firstWhere((school) => school.id == schoolId);
    } catch (e) {
      // Handle the case when no school is found
      return null;
    }
  }

  double? _calculateDistance(LatLng? schoolLocation) {
    if (userLocation == null || schoolLocation == null) return null;
    final Distance distance = Distance();
    return distance(userLocation!, schoolLocation) / 1000;
  }

  void _navigateToRegister() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const SchoolRegistrationPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.primaryColor,
        centerTitle: true,
        title: Text('Find Quran Courses', style: AppTextStyles.headerStyle.copyWith(color: Colors.white)),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () {
              // Navigate to the LogoutPage
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const LogoutPage()),
              );
            },
          ),
        ],
      ),

      body: Column(
        children: [
          _buildSearchFilters(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
            child: Row(
              children: [
                Text('${filteredCourses.length} courses found', style: AppTextStyles.normalTextStyle),
              ],
            ),
          ),
          Expanded(child: _buildCourseList()),
        ],
      ),
      bottomNavigationBar: CustomBottomNav(currentIndex: 1),
    );
  }

  Widget _buildSearchFilters() {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        children: [
          TextField(
            decoration: const InputDecoration(
              labelText: 'Search Courses',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.search),
            ),
            onChanged: (value) {
              searchQuery = value;
              _filterCourses();
            },
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Category'),
                  value: selectedCategory,
                  items: ['All', 'Quran', 'Tajweed', 'Arabic'].map((category) {
                    return DropdownMenuItem<String>(
                      value: category,
                      child: Text(category, style: AppTextStyles.normalTextStyle),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        selectedCategory = value;
                        _filterCourses();
                      });
                    }
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: DropdownButtonFormField<String>(
                  decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Mode'),
                  value: selectedMode,
                  items: ['All', 'Online', 'Offline'].map((mode) {
                    return DropdownMenuItem<String>(
                      value: mode,
                      child: Text(mode, style: AppTextStyles.normalTextStyle),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        selectedMode = value;
                        _filterCourses();
                      });
                    }
                  },
                ),
              ),
              IconButton(
                icon: const Icon(Icons.filter_alt_outlined),
                onPressed: _showAdvancedFilters,
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showAdvancedFilters() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Advanced Filters', style: AppTextStyles.subHeaderStyle),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CheckboxListTile(
                title: const Text('Show Online Courses Only'),
                value: showOnlineOnly,
                onChanged: (value) {
                  setState(() {
                    showOnlineOnly = value ?? false;
                    _filterCourses();
                  });
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCourseList() {
    return ListView.builder(
      itemCount: filteredCourses.length,
      itemBuilder: (context, index) {
        final course = filteredCourses[index];
        final school = _getSchoolForCourse(course.schoolId);
        return _buildCourseCard(course, school);
      },
    );
  }

  Widget _buildCourseCard(Course course, School? school) {
    return Card(
      elevation: 4,
      color: AppColors.secondaryColor.withOpacity(0.2),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(course.name, style: AppTextStyles.subHeaderStyle),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: _getCourseTypeColor(course.type),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(course.type, style: const TextStyle(color: Colors.white)),
            ),
            const SizedBox(height: 6),
            Text(course.description, style: AppTextStyles.normalTextStyle),
            if (school != null) ...[
              const SizedBox(height: 8),
              Text('School: ${school.name}', style: AppTextStyles.normalTextStyle),
              TextButton(
                onPressed: () {
                  final url = school.locationUrl;
                  // You can use url_launcher to launch the URL
                },
                child: const Text('View Location', style: TextStyle(color: Colors.blue)),
              ),
              Text(
                'Distance: ${_calculateDistance(LatLng(school.latitude, school.longitude))?.toStringAsFixed(2)} km',
                style: AppTextStyles.normalTextStyle,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Color _getCourseTypeColor(String type) {
    switch (type.toLowerCase()) {
      case 'quran':
        return Colors.green;
      case 'tajweed':
        return Colors.blue;
      case 'arabic':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }
}