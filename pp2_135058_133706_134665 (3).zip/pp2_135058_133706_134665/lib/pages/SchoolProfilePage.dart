import 'package:flutter/material.dart';
import '../models/School.dart';
import '../models/SchoolData.dart';
import 'package:url_launcher/url_launcher.dart';
import 'MapViewPage.dart';
import '../constants/constants.dart';

class SchoolProfilePage extends StatelessWidget {
  final School school;

  const SchoolProfilePage({Key? key, required this.school}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final schoolCourses = courses.where((c) => c.schoolId == school.id).toList();

    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        title: Text(school.name, style: AppTextStyles.headerStyle.copyWith(color: Colors.white)),
        backgroundColor: AppColors.primaryColor,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SchoolLocationMapPage(
                      latitude: school.latitude,
                      longitude: school.longitude,
                    ),
                  ),
                );
              },
              icon: Icon(Icons.map, color: Colors.white,),
              label: Text('View Location on Map'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.secondaryColor,
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: [
                  Card(
                    color: AppColors.backgroundColor,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    elevation: 4,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("School ID: ${school.id}", style: TextStyle(fontSize: 18, color: Colors.black87)),
                          SizedBox(height: 10),
                          Text("Name: ${school.name}", style: TextStyle(fontSize: 18, color: Colors.black87)),
                          SizedBox(height: 10),
                          InkWell(
                            onTap: () => launchUrl(Uri.parse(school.locationUrl)),
                            child: Text(
                              "View Location on Map",
                              style: TextStyle(fontSize: 18, color: Colors.blue, decoration: TextDecoration.underline),
                            ),
                          ),
                          SizedBox(height: 10),
                          Text("Vision: ${school.vision}", style: TextStyle(fontSize: 18, color: Colors.black87)),
                          SizedBox(height: 10),
                          Text("Description: ${school.description}", style: TextStyle(fontSize: 18, color: Colors.black87)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text('Courses Offered:', style: AppTextStyles.subHeaderStyle.copyWith(fontSize: 22, color: Color(0xFF8B8380),)),
                  const SizedBox(height: 10),
                  ...schoolCourses.map(
                        (course) => Card(
                      color: AppColors.backgroundColor,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      elevation: 3,
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Course ID: ${course.courseId}', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black87)),
                            Text('Name: ${course.name}', style: TextStyle(color: Colors.black87)),
                            Text('Instructor: ${course.instructor}', style: TextStyle(color: Colors.black87)),
                            Text('Type: ${course.type}', style: TextStyle(color: Colors.black87)),
                            Text('Mode: ${course.mode}', style: TextStyle(color: Colors.black87)),
                            Text('Start Date: ${course.startDate}', style: TextStyle(color: Colors.black87)),
                            Text('End Date: ${course.endDate}', style: TextStyle(color: Colors.black87)),
                            Text('Age Group: ${course.age}', style: TextStyle(color: Colors.black87)),
                            Text('Gender: ${course.gender}', style: TextStyle(color: Colors.black87)),
                            Text('Prerequisites: ${course.prerequisites}', style: TextStyle(color: Colors.black87)),
                            Text('Contact: ${course.contact}', style: TextStyle(color: Colors.black87)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
