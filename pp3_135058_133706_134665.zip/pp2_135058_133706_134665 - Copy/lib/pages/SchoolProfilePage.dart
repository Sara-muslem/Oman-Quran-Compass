import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/Course.dart';
import '../models/School.dart';
import '../models/SchoolData.dart';
import 'AddCoursePage.dart';
import 'MapViewPage.dart';
import '../constants/constants.dart';
import 'SchoolEditPage.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SchoolProfilePage extends StatefulWidget {
  final School school;

  const SchoolProfilePage({Key? key, required this.school}) : super(key: key);

  @override
  State createState() => _SchoolProfilePageState();
}

class _SchoolProfilePageState extends State<SchoolProfilePage> {
  late School _school;
  late List schoolCourses = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _school = widget.school;
    _loadCourses();
  }
  // Fixed to properly fetch courses from Firebase
  Future _loadCourses() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // First fetch all courses
      await fetchCourses();

      // Then filter for this school
      setState(() {
        schoolCourses = courses.where((c) => c.schoolId == widget.school.id).toList();
        _isLoading = false;
      });
    } catch (e) {
      print('Error loading courses: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _navigateToAddCourse() async {
    final added = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddCoursePage(schoolId: widget.school.id),
      ),
    );

    if (added == true) {
      // Reload courses when returning from add page
      await _loadCourses();
    }
  }

  @override
  Widget build(BuildContext context) {
    // Don't recalculate courses here - use the state variable
    // This was overriding your loaded courses from Firebase

    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        title: Text(
          widget.school.name,
          style: AppTextStyles.headerStyle.copyWith(color: Colors.white),
        ),
        backgroundColor: AppColors.primaryColor,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit, color: Colors.white),
            onPressed: () async {
              final updatedSchool = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => SchoolEditPage(school: widget.school),
                ),
              );

              if (updatedSchool != null && updatedSchool is School) {
                setState(() {
                  _school = updatedSchool;
                });
              }

            },
          ),
          // Add refresh button to manually reload courses
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: _loadCourses,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SchoolLocationMapPage(
                      latitude: widget.school.latitude,
                      longitude: widget.school.longitude,
                    ),
                  ),
                );
              },
              icon: const Icon(Icons.map, color: Colors.white),
              label: const Text('View Location on Map'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.secondaryColor,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: [
                  Card(
                    color: AppColors.backgroundColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 4,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildInfoText("School ID", widget.school.id),
                          _buildInfoText("Name", widget.school.name),
                          InkWell(
                            onTap: () async {
                              final url = Uri.parse(widget.school.locationUrl);
                              if (await canLaunchUrl(url)) {
                                await launchUrl(url);
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text("Could not launch map URL")),
                                );
                              }
                            },
                            child: Text(
                              "View Location on Map",
                              style: AppTextStyles.normalTextStyle.copyWith(
                                color: Colors.blue,
                                decoration: TextDecoration.underline,
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          _buildInfoText("Vision", widget.school.vision),
                          _buildInfoText("Description", widget.school.description),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Courses Offered:',
                        style: AppTextStyles.subHeaderStyle.copyWith(
                          fontSize: 22,
                          color: const Color(0xFF8B8380),
                        ),
                      ),
                      TextButton.icon(
                        onPressed: _navigateToAddCourse,
                        icon: const Icon(Icons.add, color: Colors.green),
                        label: const Text('Add Course', style: TextStyle(color: Colors.green)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  _isLoading
                      ? const Center(child: CircularProgressIndicator())
                      : schoolCourses.isEmpty
                      ? const Center(child: Text('No courses found for this school'))
                      : GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: schoolCourses.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 0.75,
                    ),
                    itemBuilder: (context, index) {
                      final course = schoolCourses[index];
                      return Card(
                        color: AppColors.backgroundColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        elevation: 3,
                        child: Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildCourseText('Name', course.name),
                              _buildCourseText('Instructor', course.instructor),
                              _buildCourseText('Type', course.type),
                              _buildCourseText('Mode', course.mode),
                              _buildCourseText('Start', course.startDate),
                              _buildCourseText('End', course.endDate),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoText(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(
        "$label: $value",
        style: AppTextStyles.normalTextStyle.copyWith(fontSize: 18),
      ),
    );
  }

  Widget _buildCourseText(String label, String value) {
    return Text(
      '$label: $value',
      style: AppTextStyles.normalTextStyle.copyWith(color: Colors.black87),
    );
  }
}