import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/School.dart'; // Import the global list
import '../models/SchoolData.dart'; // Import the global list
import 'LocationPickerPage.dart';
import 'package:latlong2/latlong.dart';
import '../constants/constants.dart'; // Import the constants
import 'ScoolListPage.dart';

class SchoolRegistrationPage extends StatefulWidget {
  const SchoolRegistrationPage({Key? key}) : super(key: key);

  @override
  _SchoolRegistrationPageState createState() => _SchoolRegistrationPageState();
}

class _SchoolRegistrationPageState extends State<SchoolRegistrationPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _visionController = TextEditingController();
  Future<void> _pickLocationFromMap() async {
    final LatLng? pickedLocation = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => LocationPickerPage()),
    );

    if (pickedLocation != null) {
      setState(() {
        _latitude = pickedLocation.latitude;
        _longitude = pickedLocation.longitude;
      });
    }
  }

  final ImagePicker _picker = ImagePicker();
  XFile? _pickedImage;
  String? _imagePath;
  double? _latitude;
  double? _longitude;

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _pickedImage = pickedFile;
        _imagePath = pickedFile.path;
      });
    }
  }

  void _submitRegistration() {
    if (_formKey.currentState!.validate() && _imagePath != null) {
      final newSchool = School(
        name: _nameController.text,
        latitude: _latitude!,
        longitude: _longitude!,
        logo: _imagePath!,
        description: _descriptionController.text,
        vision: _visionController.text,
      );

      registeredSchools.add(newSchool);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('School registered successfully!')),
      );

      // Navigate to the Schools List Page
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => SchoolListPage(title: "Schools List")),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all fields and upload a logo')),
      );
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.primaryColor,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white,),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 20),
          child: Form(
            key: _formKey,
            child: ListView(
              children: [
                const Text(
                  'Enter your school details:',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF8B8380),
                  ),
                  textAlign: TextAlign.left,
                ),
                const SizedBox(height: 24),
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'School Name',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value!.isEmpty ? 'Enter school name' : null,
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.secondaryColor,
                  ),
                  onPressed: _pickLocationFromMap,
                  child: Text(
                    _latitude != null && _longitude != null
                        ? 'Location Picked: ($_latitude, $_longitude)'
                        : 'Pick Location on Map',
                    style: TextStyle(color: Colors.white,)
                  ),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descriptionController,
                  decoration: const InputDecoration(
                    labelText: 'Description',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 3,
                  validator: (value) => value!.isEmpty ? 'Enter description' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _visionController,
                  decoration: const InputDecoration(
                    labelText: 'Vision',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 3,
                  validator: (value) => value!.isEmpty ? 'Enter vision' : null,
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.secondaryColor,
                  ),
                  onPressed: _pickImage,
                  child: const Text('Upload Logo',
                    style: TextStyle(color: Colors.white), ),
                ),
                if (_imagePath != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Image.file(File(_imagePath!), height: 100),
                  ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _submitRegistration,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryColor,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: const Text(
                    'Register School',
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
